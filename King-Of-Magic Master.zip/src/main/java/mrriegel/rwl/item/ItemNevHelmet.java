package mrriegel.rwl.item;

import java.util.List;
import java.util.UUID;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;

import mrriegel.rwl.init.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraftforge.common.ISpecialArmor;
import thaumcraft.api.IGoggles;
import thaumcraft.api.IRepairable;
import thaumcraft.api.IVisDiscountGear;
import thaumcraft.api.aspects.Aspect;
import thaumcraft.api.nodes.IRevealer;
import vazkii.botania.api.item.IManaProficiencyArmor;
import vazkii.botania.api.item.IPhantomInkable;
import vazkii.botania.api.mana.IManaDiscountArmor;


	public class ItemNevHelmet extends ItemArmor implements IRepairable, IVisDiscountGear, IRevealer, IGoggles, IManaDiscountArmor, IPhantomInkable, IManaProficiencyArmor
	{

	public int aType;
	

	public ItemNevHelmet(ArmorMaterial material, int renderIndex, int armorType, int it) {
		super(material, renderIndex, armorType);
		aType = it;
	}
	
	@Override
	public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type){
		if(this.armorType == 2){
			return "rwl:textures/models/armor/nev_2.png";
		}
		return "rwl:textures/models/armor/nev_1.png";
	}
	
	@Override
	public boolean getIsRepairable(ItemStack p_82789_1_, ItemStack p_82789_2_) {
		if (p_82789_2_.getItem().equals(ModItems.nev)) {
			return true;
		}
		return false;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Multimap getAttributeModifiers(ItemStack stack)
{
	 Multimap mods = HashMultimap.create();
	 
 if(this == ModItems.nev_helmet) mods.put(SharedMonsterAttributes.followRange.getAttributeUnlocalizedName(), new AttributeModifier(UUID.fromString("1bca943c-3cf5-42cc-a3df-2ed994ae0001"), "fr", 0.2D, 0));
	 return mods;
}
	
	@Override
	public void onArmorTick(World world, EntityPlayer player, ItemStack itemStack) 
{
		player.addPotionEffect(new PotionEffect(Potion.nightVision.getId(), 400, 0));
	}
	
	 @SuppressWarnings({ "unchecked", "rawtypes" })
		public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean par4)
	    {
	        super.addInformation(stack, player, list, par4);
	        list.add((new StringBuilder()).append(EnumChatFormatting.DARK_PURPLE).append(StatCollector.translateToLocal("tc.visdiscount")).append(": ").append(getVisDiscount(stack, player, null)).append("%").toString());
	        if(this.aType == 1)
	        {
}
	    }

	 @Override
		public boolean showIngamePopups(ItemStack itemstack, EntityLivingBase player) {
			int type = ((ItemArmor)itemstack.getItem()).armorType;
			return type == 0;
	}

	@Override
	public boolean showNodes(ItemStack itemstack, EntityLivingBase player) {
		int type = ((ItemArmor)itemstack.getItem()).armorType;
		return type == 0;
	}

	@Override
	public int getVisDiscount(ItemStack stack, EntityPlayer player,
			Aspect aspect) {
		int type = ((ItemArmor)stack.getItem()).armorType;
		
		return discount[aType][type];
	}
	
	public static int[][] discount = new int[][]{{5,5,3,2},{8,10,7,5},{10,15,8,7},{2,3,2,1}};

 
	@Override
	public float getDiscount(ItemStack stack, int slot, EntityPlayer player){
	    return 0.25F;
	}

	public boolean hasPhantomInk(ItemStack stack) {
	    if(stack.getTagCompound() == null)
	        return false;
	    return stack.getTagCompound().getBoolean("phantomInk");
	}


	public void setPhantomInk(ItemStack stack, boolean ink) {

	    NBTTagCompound tag = stack.getTagCompound();
	    if(tag == null){
	        tag = new NBTTagCompound();
	        stack.setTagCompound(tag);
	    }
	    tag.setBoolean("phantomInk", ink);
	}

	@Override
	public boolean shouldGiveProficiency(ItemStack itemStack, int i, EntityPlayer player){
	    return true;
	}

	}
	
