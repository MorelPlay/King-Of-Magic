package mrriegel.rwl.gui;

public class GuiIDs {

	public static final int NEVTOOL = 0;
	public static final int BAG = 1;
	public static final int TALIBAG = 2;
	public static final int COMBOBAG = 3;

}
