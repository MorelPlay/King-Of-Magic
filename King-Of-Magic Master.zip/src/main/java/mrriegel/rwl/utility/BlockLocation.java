package mrriegel.rwl.utility;

public class BlockLocation {
	public int x, y, z;

	public BlockLocation(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

}