package mrriegel.rwl.gui;

public interface IContainer {
	public void onSlotChanged();
}
